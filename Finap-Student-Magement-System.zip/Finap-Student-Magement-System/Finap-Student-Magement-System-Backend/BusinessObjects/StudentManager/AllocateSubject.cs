﻿using System;

namespace BusinessObjects.TestModule
{
    public class AllocateSubject
    {
        public int AllocateSubjectID { get; set; }
        public int TeacherID { get; set; }
        public int SubjectID { get; set; }
        public string SubjectName { get; set; }

    }
}
