﻿using System;

namespace BusinessObjects.TestModule
{
    public class Class
    {
        public int ClassroomID { get; set; }
        public string ClassroomName { get; set; }
        
    }
}
