﻿using System;

namespace BusinessObjects.TestModule
{
    public class AllocateClassroom
    {
        public int AllocateClassroomID { get; set; }
        public int TeacherID { get; set; }
        public int ClassroomID { get; set; }
        public string ClassroomName { get; set; }

    }
}
