﻿namespace BusinessObjects.Base
{
    public class AppSettings
    {
        public static string ConnectionString { get; set; }
    }
}
