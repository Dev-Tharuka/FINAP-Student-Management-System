﻿using System;

namespace BusinessObjects.TestModule
{
    public class Subject
    {
        public int SubjectID { get; set; }
        public string SubjectName { get; set; }

    }
}
