﻿using System;

namespace BusinessObjects.TestModule
{
    public class StudentReport
    {
             public string FirstName { get; set; }
             public string LastName { get; set; }
             public string Classroom { get; set; }
             public string ContactPerson { get; set; }
             public string EmailAddress { get; set; }
             public string ContactNo { get; set; }
             public string DOB { get; set; }
             public string Subject { get; set; }
             public string Teacher { get; set; }

    }
}
